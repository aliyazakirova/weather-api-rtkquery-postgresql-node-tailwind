const { Pool } = require('pg');

const pool = new Pool({
  host: '172.23.0.2',
  port: 5432,
  user: 'admin',
  password: '1234',
  database: 'history_query',
});

module.exports = pool;
