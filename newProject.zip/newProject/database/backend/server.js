const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const pool = require('./db');

const app = express();
app.use(bodyParser.json());

app.use(
  cors({
    origin: '*',
  })
);

app.post('/storeWeatherData', async (req, res) => {
  const { data } = req.body;
  const country = data.location.country;
  const city = data.location.name;
  const temp_c = data.current.temp_c;
  const feelslike_c = data.current.feelslike_c;
  const localtime_ = data.location.localtime;

  console.log(localtime_, feelslike_c, temp_c, city, country);

  try {
    await pool.query(
      'INSERT INTO history_query (country , city, temp_c , feelslike_c , localtime_) VALUES ($1 , $2 , $3 , $4, $5)',
      [country, city, temp_c, feelslike_c, localtime_]
    );

    res.status(200).send('Weather data stored successfully');
  } catch (error) {
    console.error('Error storing weather data:', error);
    res.status(500).send('Internal server error');
  }
});

app.listen(3005, () => {
  console.log('Server is running on port 3005');
});
