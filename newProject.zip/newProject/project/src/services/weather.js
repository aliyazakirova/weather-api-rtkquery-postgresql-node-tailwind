import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';

export const weatherApi = createApi({
  reducerPath: 'weatherApi',
  baseQuery: fetchBaseQuery({
    baseUrl: 'https://api.weatherapi.com/v1',
  }),
  endpoints: (builder) => ({
    getWeather: builder.query({
      query: (city) =>
        `/current.json?key=b552cc8468c7462c8d3205736232712&q=${city}&aqi=no`,
    }),
  }),
});

// Export the auto-generated hooks based on the endpoints
export const { useGetWeatherQuery } = weatherApi;
