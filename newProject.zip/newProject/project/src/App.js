import './App.css';
import React, { useState, useEffect } from 'react';
import { useGetWeatherQuery } from './services/weather';

function App() {
  const [selectedValue, setSelectedValue] = useState('');
  const { data } = useGetWeatherQuery(selectedValue);

  const handleSelectChange = (event) => {
    setSelectedValue(event.target.value);
    console.log(event.target.value);
  };

  useEffect(() => {
    console.log('value change', selectedValue);
  }, [selectedValue]);

  useEffect(() => {
    console.log('Weather data:', data);
    handleStoreWeatherData(data);
  }, [data]);

  const handleStoreWeatherData = (weatherData) => {
    fetch('http://localhost:13000/storeWeatherData', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ data: weatherData }),
    })
      .then((response) => {
        if (response.ok) {
          return response.text();
        }
        throw new Error('Network response was not ok.');
      })
      .then((data) => {
        console.log(data);
      })
      .catch((error) => {
        console.error('Error storing weather data:', error);
      });
  };

  return (
    <div className="App flex flex-col gap-[30px] w-1/2 justify-center items-center">
      <form class="max-w-sm mx-auto">
        <label
          for="countries"
          class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
        >
          Select your country
        </label>
        <select
          id="countries"
          class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
          onChange={handleSelectChange}
          value={selectedValue}
        >
          <option value="Istanbul">Istanbul</option>
          <option value="Moscow">Moscow</option>
          <option value="London">London</option>
        </select>
      </form>

      <div class="relative overflow-x-auto shadow-md sm:rounded-lg">
        {data && (
          <table class="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400">
            <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
              <tr>
                <th scope="col" class="px-6 py-3">
                  Country
                </th>
                <th scope="col" class="px-6 py-3">
                  City
                </th>
                <th scope="col" class="px-6 py-3">
                  temperature
                </th>
                <th scope="col" class="px-6 py-3">
                  feels Like
                </th>
                <th scope="col" class="px-6 py-3">
                  Local Time
                </th>
              </tr>
            </thead>
            <tbody>
              <tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600">
                <th
                  scope="row"
                  class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white"
                >
                  {data.location.country}
                </th>
                <td class="px-6 py-4">{data.location.name}</td>
                <td class="px-6 py-4">{data.current.temp_c}</td>
                <td class="px-6 py-4">{data.current.feelslike_c}</td>
                <td class="px-6 py-4">{data.location.localtime}</td>
              </tr>
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

export default App;
