import { configureStore } from '@reduxjs/toolkit';
import { weatherApi } from '../services/weather'; // Import weatherApi from weather file

// Create the Redux store
export const store = configureStore({
  reducer: {
    // Add the API slice reducer to the store
    [weatherApi.reducerPath]: weatherApi.reducer, // Update to use weatherApi
  },
  // Add middleware for API requests
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware().concat(weatherApi.middleware), // Update to use weatherApi
});

// Export the store
export default store;
